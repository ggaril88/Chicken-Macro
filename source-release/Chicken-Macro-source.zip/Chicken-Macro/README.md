# Chicken - Macro Studio

## Run
1. Close any running Chicken and extract this ZIP into a new folder.
2. py -m pip install -r requirements.txt
3. py chicken.py
Keep the sounds folder and chicken.ico next to chicken.py. Windows only.

## Changes in this version
- Compact layout. Default window is 780x430 (wide and short). Resize it freely;
  size and position are remembered. Settings > Interface > Reset window size restores the default.
- Bind keys are now swallowed: pressing a bound combo (for example Ctrl + A) plays
  the macro and no longer reaches the app in front. Applies while hotkeys are enabled.
- Ctrl/Alt/Shift used to start a bind are held back while recording, so a bind
  never leaves a stray modifier in the list, not even briefly. A modifier tapped
  on its own is still recorded.
- Playback waits (up to 3 s) for you to release the bind's Ctrl/Alt/Shift before
  it starts, so they do not mix into the macro's keys.
- Hints about this are in Settings > Hotkeys and in the bind dialog.

## Notes
- Prefer Ctrl/Alt combos or F-keys for binds. A bare letter bind is swallowed everywhere
  while hotkeys are on, so you could not type that letter. Use Disable hotkeys [Home] to type.
- Ctrl is passed through when you press a bind; only the final key is blocked.
- Needs pynput 1.8.0+.

## Data
%LOCALAPPDATA%\Chicken\macros.json and chicken_settings.json (existing files are reused).

## Build (optional)
py -m pip install pyinstaller
py -m PyInstaller --clean --onefile --windowed --name Chicken --icon chicken.ico --add-data "chicken.ico;." --add-data "sounds;sounds" chicken.py

## Responsibility
Automation may violate game or service rules and can lead to bans. Use only
where permitted; you are responsible for your use. No guarantee of compatibility.

## Verification
Key-handling logic (suppression, bind recording, ordering) was tested headlessly
with simulated events. The real Windows UI, hooks, audio and EXE were not tested.
