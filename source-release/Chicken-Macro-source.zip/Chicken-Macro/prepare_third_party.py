"""Run beside chicken-license-review.zip: py prepare_third_party.py
Downloads missing upstream materials and stages third_party/ without modifying Chicken.
Requires internet, Python standard library only.
"""
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import tempfile
import urllib.request
import zipfile

BASE = Path(__file__).resolve().parent
MAX_BYTES = 30_000_000


def download(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'Chicken-Macro-license-preparation/1.0'})
    with urllib.request.urlopen(request, timeout=40) as r:
        data = r.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise ValueError('Download exceeds size limit: ' + url)
    return data


def main():
    source = BASE / 'chicken-license-review.zip'
    target = BASE / 'third_party'
    if target.exists():
        raise ValueError('third_party already exists. Keep it as a backup under another name before running this script.')
    with tempfile.TemporaryDirectory(prefix='chicken-notices-', dir=BASE) as temp:
        stage = Path(temp) / 'third_party'
        stage.mkdir()
        with zipfile.ZipFile(source) as z:
            report = json.loads(z.read('report.json'))
            packages = {p['name'].lower(): p['version'] for p in report['packages']}
            if packages.get('pynput') != '1.8.2':
                raise ValueError('This preparation script expects the reported pynput 1.8.2. No output installed.')
            for item in z.infolist():
                name = PurePosixPath(item.filename)
                if not name.parts or name.parts[0] != 'licenses' or item.is_dir():
                    continue
                if name.is_absolute() or '..' in name.parts or any(':' in x or '\\' in x for x in name.parts):
                    raise ValueError('Unsafe archive member')
                if item.file_size > 2_000_000:
                    raise ValueError('Unexpected large notice')
                dest = stage.joinpath(*name.parts)
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(z.read(item))
        provenance = []
        urls = [
            ('licenses/tcl/Tcl-9.0.4-license.terms',
             'https://raw.githubusercontent.com/tcltk/tcl/core-9-0-4/license.terms'),
            ('licenses/tk/Tk-9.0.4-license.terms',
             'https://raw.githubusercontent.com/tcltk/tk/core-9-0-4/license.terms'),
            ('licenses/gnu/GPL-3.0.txt', 'https://www.gnu.org/licenses/gpl-3.0.txt'),
            ('licenses/gnu/LGPL-3.0.txt', 'https://www.gnu.org/licenses/lgpl-3.0.txt')]
        for name, url in urls:
            print('Downloading ' + name)
            data = download(url)
            text = data.decode('utf-8-sig')
            if '<html' in text.lower() or len(text) < 500:
                raise ValueError('Unexpected license response: ' + url)
            if name.endswith('license.terms') and 'copyright' not in text.lower():
                raise ValueError('Missing copyright notice: ' + url)
            dest = stage / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            provenance.append({'file': name, 'source': url, 'sha256': hashlib.sha256(data).hexdigest()})
        # Download the exact library source archive, not an unversioned branch.
        print('Downloading pynput 1.8.2 source metadata')
        metadata = json.loads(download('https://pypi.org/pypi/pynput/1.8.2/json'))
        artifact = next(x for x in metadata['urls'] if x['packagetype'] == 'sdist')
        name = artifact['filename']
        if Path(name).name != name or not name.endswith(('.tar.gz', '.zip')):
            raise ValueError('Unexpected source archive name')
        url = artifact['url']
        if not url.startswith('https://files.pythonhosted.org/'):
            raise ValueError('Unexpected source archive host')
        data = download(url)
        digest = hashlib.sha256(data).hexdigest()
        if digest != artifact['digests']['sha256']:
            raise ValueError('Library source archive hash mismatch')
        dest = stage / 'sources' / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        provenance.append({'file': 'sources/' + name, 'source': url, 'sha256': digest})
        (stage / 'PROVENANCE.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')
        (stage / 'README.txt').write_text(
            'Chicken Macro third-party materials\n\n'
            'Collected package notices are retained verbatim. Some packages are build tools,\n'
            'not necessarily runtime components. No claim that this inventory is exhaustive.\n'
            'Tcl/Tk 9.0.4 notices and GNU GPLv3/LGPLv3 texts downloaded from upstream.\n'
            'Exact pynput 1.8.2 source archive included; hash checked against PyPI metadata.\n'
            'Third-party components keep their own licenses. Chicken resale restrictions\n'
            'do not apply to the libraries independently.\n\n'
            'This folder alone is not proof of license compliance. Review application\n'
            'license exceptions, source/rebuild instructions and bundled components before release.\n',
            encoding='utf-8')
        shutil.move(str(stage), str(target))
    print('DONE: third_party folder created.')
    print('No Chicken source, settings, macros or installer were changed.')
    print('Keep this folder. Do not rebuild yet; source/rebuild instructions and licensing exceptions remain to be prepared.')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        raise SystemExit('STOPPED: ' + str(exc) + '\nExisting Chicken files were not changed. No incomplete third_party folder was installed.')
