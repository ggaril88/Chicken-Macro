"""Run in the Chicken project with the Python used to build it: py collect_notices.py
Creates chicken-license-review.zip. Does not install packages or modify Chicken data.
"""
import ast
import importlib.metadata as metadata
import json
from pathlib import Path
import platform
import sys
import zipfile


def main():
    base = Path(__file__).resolve().parent
    archive = base / 'chicken-license-review.zip'
    report = {'python_version': platform.python_version(), 'platform': platform.system(),
              'machine': platform.machine(), 'packages': [], 'license_files': [],
              'bundle_files': [], 'analysis_package_hints': [], 'notes': []}
    payload = {}
    names = ('pynput', 'six', 'pyinstaller', 'pyinstaller-hooks-contrib',
             'altgraph', 'pefile', 'pywin32-ctypes', 'packaging', 'setuptools')
    for name in names:
        try:
            dist = metadata.distribution(name)
        except metadata.PackageNotFoundError:
            report['notes'].append('Not installed: ' + name)
            continue
        m = dist.metadata
        info = {'name': m.get('Name', name), 'version': dist.version,
                'license_expression': m.get('License-Expression'),
                'license_metadata': m.get('License'),
                'license_classifiers': [v for v in m.get_all('Classifier', []) if v.startswith('License ::')],
                'requires_dist': m.get_all('Requires-Dist', []),
                'project_urls': m.get_all('Project-URL', []), 'collected_licenses': []}
        for f in dist.files or []:
            rel = str(f).replace('\\', '/')
            leaf = Path(rel).name.lower()
            if not leaf.startswith(('license', 'licence', 'copying', 'notice', 'authors', 'copyright')):
                continue
            p = Path(dist.locate_file(f))
            if not p.is_file() or p.stat().st_size > 2_000_000:
                continue
            target = 'licenses/packages/' + name + '/' + str(len(info['collected_licenses']) + 1) + '-' + p.name
            payload[target] = p.read_bytes()
            info['collected_licenses'].append(target)
        if not info['collected_licenses']:
            report['notes'].append('No installed license text found for ' + name)
        report['packages'].append(info)
    prefixes = list(dict.fromkeys([Path(sys.base_prefix), Path(sys.prefix)]))
    for prefix in prefixes:
        for filename in ('LICENSE.txt', 'LICENSE', 'COPYING'):
            p = prefix / filename
            if p.is_file():
                key = 'licenses/python/' + p.name
                payload[key] = p.read_bytes()
        tcl = prefix / 'tcl'
        if tcl.exists():
            for p in tcl.rglob('*'):
                if p.is_file() and p.name.lower() in ('license', 'license.terms', 'license.txt', 'copying', 'copyright'):
                    payload['licenses/tcl-tk/' + p.relative_to(tcl).as_posix()] = p.read_bytes()
    bundle = base / 'dist' / 'Chicken'
    if bundle.is_dir():
        report['bundle_files'] = sorted(p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file())
        for p in bundle.rglob('*'):
            if p.is_file() and p.name.lower().startswith(('license', 'licence', 'copying', 'copyright', 'notice')) and p.stat().st_size < 2_000_000:
                payload['licenses/bundle/' + p.relative_to(bundle).as_posix()] = p.read_bytes()
    else:
        report['notes'].append('dist/Chicken not found; no built-file inventory collected.')
    toc = base / 'build' / 'Chicken' / 'Analysis-00.toc'
    if toc.is_file():
        try:
            data = ast.literal_eval(toc.read_text(encoding='utf-8'))
            hints = set()
            def walk(x):
                if isinstance(x, (list, tuple)):
                    if len(x) == 3 and isinstance(x[0], str) and isinstance(x[2], str) and x[2] in ('PYMODULE', 'PYSOURCE', 'EXTENSION'):
                        hints.add(x[0])
                    for y in x:
                        walk(y)
            walk(data)
            report['analysis_package_hints'] = sorted(hints)
        except Exception as e:
            report['notes'].append('Could not parse build analysis: ' + type(e).__name__)
    report['license_files'] = sorted(payload)
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('report.json', json.dumps(report, ensure_ascii=False, indent=2))
        for name, contents in sorted(payload.items()):
            z.writestr(name, contents)
    print('Created ' + archive.name)
    print('Contains package metadata, license texts and relative build-file names only.')
    print('No Chicken macros, settings, credentials or source code were collected.')
    print('This report is for review; it does not certify license compliance.')


if __name__ == '__main__':
    main()
